Imports DirectX.Capture

Public Class MW
    Inherits System.Windows.Forms.Form

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Call to AddCam to select an available camera
        Dim AddCamera As New AddCam()
        AddCamera.ShowDialog(Me)

        CaptureInformation.CaptureInfo.PreviewWindow = Me.videoBoard
        'CaptureInformation.CaptureInfo.PreviewWindow.Width = 1920
        'CaptureInformation.CaptureInfo.PreviewWindow.Height = 1080
        'Define RefreshImage as event handler of FrameCaptureComplete
        AddHandler CaptureInformation.CaptureInfo.FrameCaptureComplete, AddressOf RefreshImage

        CaptureInformation.Counter = 1
        CaptureInformation.CounterFrames = 1


        Me.Show()

        'Initialization of ConfWindow
        CaptureInformation.ConfWindow = New CW()
        CaptureInformation.ConfWindow.Refresh()
        CaptureInformation.ConfWindow.Show()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents videoBoard As System.Windows.Forms.Panel
    Friend WithEvents cmdFrame As System.Windows.Forms.Button
    Friend WithEvents cmdStart As System.Windows.Forms.Button
    Friend WithEvents cmdStop As System.Windows.Forms.Button
    Friend WithEvents pcbFrame As System.Windows.Forms.PictureBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.videoBoard = New System.Windows.Forms.Panel()
        Me.cmdFrame = New System.Windows.Forms.Button()
        Me.cmdStart = New System.Windows.Forms.Button()
        Me.cmdStop = New System.Windows.Forms.Button()
        Me.pcbFrame = New System.Windows.Forms.PictureBox()
        CType(Me.pcbFrame, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'videoBoard
        '
        Me.videoBoard.Location = New System.Drawing.Point(2, 0)
        Me.videoBoard.Name = "videoBoard"
        Me.videoBoard.Size = New System.Drawing.Size(1479, 732)
        Me.videoBoard.TabIndex = 0
        '
        'cmdFrame
        '
        Me.cmdFrame.Location = New System.Drawing.Point(1390, 678)
        Me.cmdFrame.Name = "cmdFrame"
        Me.cmdFrame.Size = New System.Drawing.Size(75, 23)
        Me.cmdFrame.TabIndex = 1
        Me.cmdFrame.Text = "Frame"
        '
        'cmdStart
        '
        Me.cmdStart.Location = New System.Drawing.Point(1390, 586)
        Me.cmdStart.Name = "cmdStart"
        Me.cmdStart.Size = New System.Drawing.Size(75, 23)
        Me.cmdStart.TabIndex = 2
        Me.cmdStart.Text = "Start"
        '
        'cmdStop
        '
        Me.cmdStop.Enabled = False
        Me.cmdStop.Location = New System.Drawing.Point(1390, 633)
        Me.cmdStop.Name = "cmdStop"
        Me.cmdStop.Size = New System.Drawing.Size(75, 23)
        Me.cmdStop.TabIndex = 3
        Me.cmdStop.Text = "Stop"
        '
        'pcbFrame
        '
        Me.pcbFrame.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pcbFrame.Location = New System.Drawing.Point(1279, 0)
        Me.pcbFrame.Name = "pcbFrame"
        Me.pcbFrame.Size = New System.Drawing.Size(202, 153)
        Me.pcbFrame.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pcbFrame.TabIndex = 4
        Me.pcbFrame.TabStop = False
        '
        'MW
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(1483, 744)
        Me.Controls.Add(Me.pcbFrame)
        Me.Controls.Add(Me.cmdStop)
        Me.Controls.Add(Me.cmdStart)
        Me.Controls.Add(Me.cmdFrame)
        Me.Controls.Add(Me.videoBoard)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "MW"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Main Window"
        CType(Me.pcbFrame, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Public Sub RefreshImage(ByVal Frame As System.Windows.Forms.PictureBox)
        Dim s() As String
        Dim fmt As String

        s = CaptureInformation.PathVideo.Split(".")
        fmt = CaptureInformation.ConfWindow.CmbFormat.SelectedItem()
        Me.pcbFrame.Image = Frame.Image
        'Me.pcbFrame.Image.Save(s(0) + CStr(CaptureInformation.CounterFrames) + ".jpg", System.Drawing.Imaging.ImageFormat.Jpeg)


        If String.Compare(fmt, "tiff") = 0 Then
            Me.pcbFrame.Image.Save(s(0) + CStr(CaptureInformation.CounterFrames) + "." + fmt, System.Drawing.Imaging.ImageFormat.Tiff)
        End If
        If String.Compare(fmt, "jpg") = 0 Then
            Me.pcbFrame.Image.Save(s(0) + CStr(CaptureInformation.CounterFrames) + "." + fmt, System.Drawing.Imaging.ImageFormat.Jpeg)
        End If
        If String.Compare(fmt, "bmp") = 0 Then
            Me.pcbFrame.Image.Save(s(0) + CStr(CaptureInformation.CounterFrames) + "." + fmt, System.Drawing.Imaging.ImageFormat.Bmp)
        End If
        If String.Compare(fmt, "png") = 0 Then
            Me.pcbFrame.Image.Save(s(0) + CStr(CaptureInformation.CounterFrames) + "." + fmt, System.Drawing.Imaging.ImageFormat.Png)
        End If
        CaptureInformation.CounterFrames += 1
            Me.pcbFrame.Refresh()
    End Sub

    Private Sub cmdFrame_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdFrame.Click
        CaptureInformation.CaptureInfo.CaptureFrame()
    End Sub

    Private Sub cmdStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdStart.Click
        CaptureInformation.CaptureInfo.Start()
        cmdStart.Enabled = False
        cmdStop.Enabled = True
    End Sub

    Private Sub cmdStop_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdStop.Click
        CaptureInformation.CaptureInfo.Stop()
        ConfParamCam()
        PrepareCam(CaptureInformation.PathVideo)
        cmdStart.Enabled = True
        cmdStop.Enabled = False
    End Sub

End Class
